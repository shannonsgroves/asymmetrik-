package businessCard;

public class Driver {
	
	//main method to show output of ContactInfo class
		public static void main(String[]args) {
			ContactInfo c=new ContactInfo();
			String document1="ASYMMETRIK LTD" +"\n"
					+ "Mike Smith" +"\n"
					+ "Senior Software Engineer"+"\n"
					+ "(410)555-1234"+"\n"
					+ "msmith@asymmetrik.com";
			
			String document2="Foobar Technologies"+"\n"+
					"Analytic Developer"+"\n"+
					"Lisa Haung"+"\n"+
					"1234 Sentry Road"+"\n"+
					"Columbia, MD 12345"+"\n"+
					"Phone: 410-555-1234"+"\n"+
					"Fax: 410-555-4321"+"\n"+
					"Email: lisa.haung@foobartech.com";
			
			String document3="Arthur Wilson\n" + 
					"Software Engineer\n" + 
					"Decision & Security Technologies\n" + 
					"ABC Technologies\n" + 
					"123 North 11th Street\n" + 
					"Suite 229\n" + 
					"Arlington, VA 22209\n" + 
					"Tel: +1 (703) 555- 1259\n" + 
					"Fax: +1 (703) 555-1200\n" + 
					"awilson@abctech.com";


			System.out.println(c.getContactInfo(document1).toString()+"\n");
			System.out.println(c.getContactInfo(document2).toString()+"\n");
			System.out.println(c.getContactInfo(document3).toString());
			
		}

}
