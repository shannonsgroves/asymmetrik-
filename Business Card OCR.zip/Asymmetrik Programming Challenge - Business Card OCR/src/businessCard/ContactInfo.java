package businessCard;

import java.util.Scanner;

public class ContactInfo implements BusinessCardParser {

	//instance variables of the class
	private String name;
	private String phoneNumber;
	private String emailAddress;


	//default constructor to initialize variables
	public ContactInfo() {
		this.name="";
		this.phoneNumber="";
		this.emailAddress="";

	}

	//constructor that takes in parameters
	public ContactInfo(String name, String phoneNumber, String emailAddress) {
		this.name=name;
		this.phoneNumber=phoneNumber;
		this.emailAddress=emailAddress;

	}

	public ContactInfo getContactInfo(String document) {
		//turns the whole string to lowercase 
		document=document.toLowerCase();
		//parses the phone number, email and name from the document 
		setInformation(document);
		setName(document);

		//creates a new contact with the updates information
		ContactInfo contact=new ContactInfo(name, phoneNumber,emailAddress);
		return contact;
	}

	//returns the full name of the individual
	public String getName() {
		return name;
	}

	//returns the phone number formatted as a sequence of digits 
	public String getPhoneNumber() {
		return phoneNumber;
	}

	//returns the email address 
	public String getEmailAddress() {
		return emailAddress;
	}

	//returns a String format of the ContactInfo object
	public String toString() {
		return "Name: "+name+"\n"+"Phone: "+phoneNumber+"\n"+"Email: "+emailAddress;
	}


	private void setInformation(String document) {
		//resets the phone number to empty 
		phoneNumber="";
		Scanner s=new Scanner(document);

		while(s.hasNext()) {
			String line =s.nextLine();//gets the next line of the String 
			Scanner wordScanner=new Scanner(line);
			wordScanner.useDelimiter(" ");//splits the line by spaces

			while(wordScanner.hasNext()) {
				String word=wordScanner.next();//gets the next word

				for(int i=0;i<word.length();i++) {
					//sets the emailAddress variable
					if(word.charAt(i)=='@') {
						emailAddress=word;
					}
				}

				String number="";
				if(word.equals("phone:")||word.equals("telephone:")||word.equals("tel:")) {
					//if the line has a phone number all the white space will be removed
					String pNumber=line.replaceAll("\\s",""); 
					//iterates through the line and records all the digits of the number
					for(int i=0;i<pNumber.length();i++) {
						if(Character.isDigit(pNumber.charAt(i))) {
							number+=pNumber.charAt(i);
							phoneNumber=number;
						}
					}
				}
				//if the phone number hasn't been found yet
				if(phoneNumber.equals("")) {
					//all the white space is removed from each line
					String pNumber=line.replaceAll("\\s", "");

					boolean isGreaterOrEqualToTen=false;
					//iterates through the line and if a number is greater than or equal
					//to 10 digits that number is assumed to be a phone number
					for(int i=0;i<pNumber.length();i++) {
						if(Character.isDigit(pNumber.charAt(i))&&pNumber.substring(i).length()>=10) {
							isGreaterOrEqualToTen=true;
							break;
						}
					}

					//if the line contains a phone number the digits are parsed from the line
					for(int i=0;i<pNumber.length();i++) {
						if(Character.isDigit(pNumber.charAt(i))&& isGreaterOrEqualToTen==true) {
							number+=pNumber.charAt(i);
							phoneNumber=number;

						}

					}


				}
			}
			wordScanner.close();

		}
		s.close();

	}

	private void setName(String document) {
		//reset name to an empty String 
		name="";
		Scanner s=new Scanner(document);

		while(s.hasNext()) {
			String line =s.nextLine();//gets the next line of the String 
			Scanner wordScanner=new Scanner(line);
			wordScanner.useDelimiter(" ");//splits the line by spaces

			while(wordScanner.hasNext()) {
				//gets the next word and stores it as a possible first name
				String firstName=wordScanner.next();

				while(wordScanner.hasNext()) {
					//gets the next word and stores it as a possible last name
					String lastName=wordScanner.next();
					//if the word is in the email it is the last name 
					if(emailAddress.contains(lastName)&&name.equals("")) {
						//capitalizes the first name
						String firstNameCapitalized="";
						firstNameCapitalized+=Character.toUpperCase(firstName.charAt(0));
						for(int i=1;i<firstName.length();i++) {
							firstNameCapitalized+=firstName.charAt(i); 
						}

						//capitalizes the last name 
						String lastNameCapitalized="";
						lastNameCapitalized+=Character.toUpperCase(lastName.charAt(0));
						for(int i=1;i<lastName.length();i++) {
							lastNameCapitalized+=lastName.charAt(i); 
						}
						//saves the first and last name 
						name=firstNameCapitalized+" "+lastNameCapitalized;
					}
				}
			}
			wordScanner.close();
		}
		s.close();

	}





}
