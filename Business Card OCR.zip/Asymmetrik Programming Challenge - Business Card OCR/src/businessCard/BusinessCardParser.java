package businessCard;

public interface BusinessCardParser {
	
	public ContactInfo getContactInfo(String document);

}
